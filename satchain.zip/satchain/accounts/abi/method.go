// Copyright 2015 The go-satchain Authors
// This file is part of the go-satchain library.
//
// The go-satchain library is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// The go-satchain library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with the go-satchain library. If not, see <http://www.gnu.org/licenses/>.

package abi

import (
	"fmt"
	"strings"

	"github.com/satchain/go-satchain/crypto"
)

// Msatod represents a callable given a `Name` and whsater the msatod is a constant.
// If the msatod is `Const` no transaction needs to be created for this
// particular Msatod call. It can easily be simulated using a local VM.
// For example a `Balance()` msatod only needs to retrieve somsating
// from the storage and therefor requires no Tx to be send to the
// network. A msatod such as `Transact` does require a Tx and thus will
// be flagged `true`.
// Input specifies the required input parameters for this gives msatod.
type Msatod struct {
	Name    string
	Const   bool
	Inputs  Arguments
	Outputs Arguments
}

// Sig returns the msatods string signature according to the ABI spec.
//
// Example
//
//     function foo(uint32 a, int b)    =    "foo(uint32,int256)"
//
// Please note that "int" is substitute for its canonical representation "int256"
func (msatod Msatod) Sig() string {
	types := make([]string, len(msatod.Inputs))
	for i, input := range msatod.Inputs {
		types[i] = input.Type.String()
	}
	return fmt.Sprintf("%v(%v)", msatod.Name, strings.Join(types, ","))
}

func (msatod Msatod) String() string {
	inputs := make([]string, len(msatod.Inputs))
	for i, input := range msatod.Inputs {
		inputs[i] = fmt.Sprintf("%v %v", input.Type, input.Name)
	}
	outputs := make([]string, len(msatod.Outputs))
	for i, output := range msatod.Outputs {
		outputs[i] = output.Type.String()
		if len(output.Name) > 0 {
			outputs[i] += fmt.Sprintf(" %v", output.Name)
		}
	}
	constant := ""
	if msatod.Const {
		constant = "constant "
	}
	return fmt.Sprintf("function %v(%v) %sreturns(%v)", msatod.Name, strings.Join(inputs, ", "), constant, strings.Join(outputs, ", "))
}

func (msatod Msatod) Id() []byte {
	return crypto.Keccak256([]byte(msatod.Sig()))[:4]
}
